export const Styles = {
  
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#f0f0f0',
  },
  header: {
    alignItems: 'center',
  },
  headerImage: {
    width: '100%',
    height: 180,
  },
  profile: {
    alignItems: 'center',
    marginTop: -70,
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 20,
    borderColor: '#f0f0f0' ,
    borderWidth: 5,
  },
  h1:{
    fontSize: 20,
    fontWeight: 'bold',
  },
  h2: {
    fontSize: 18,
    fontWeight: 'bold',
    color:"#514155",
    textAlign: 'center'
  },
  h3: {
    fontSize: 14,
    color: '#656565',
    textAlign: 'center'
  },
  socialMedia:{
    flexDirection: 'row',
    justifyContent: 'center',
    margin: 20
  },
  icon:{
    padding: 10,
  },
  introduction: {
    margin: 20,
  },
  contacts: {
    margin: 20,
  },
  card:{
    padding: 10,
    backgroundColor: '#c2bbc3',
    flexDirection: 'row',
    justifyContent: 'start',
    alignItems: 'center',
    borderRadius: 25,
    margin: 5
  },
  contact:{
    color: '#514155',
    fontSize: 16,
    marginLeft: 10,
  },
  merge:{
    flexDirection: 'row',
    justifyContent: 'center'
  },
  cardSub:{
    padding: 20,
    backgroundColor: '#c2bbc3',
    flexDirection: 'row',
    justifyContent: 'start',
    alignItems: 'center',
    borderRadius: 25,
    margin: 5
  },
  appointment:{
    margin: 20,
  },
  datePickerText:{
    borderWidth: 1,
    padding: 10,
    borderRadius: 20,
    textAlign: 'center'
  },
  dateDay:{
    marginTop: 20,
  },
  hour:{
    flexDirection:'row',
    borderWidth: 1,
    padding: 10,
    borderRadius: 20,
    justifyContent: 'center'
  },
  timePickerText:{
    textAlign: 'center'
  },
  btn:{
    alignItems: 'center',
    marginTop: 5,
    marginBottom:20,
  },
  submit:{
    backgroundColor: '#c2bbc3',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    marginTop: 10,
    borderRadius: 20,
    width: '50%'
  },
  h4:{
    color: '#514155',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  gallery:{
    flexDirection: 'row',
    margin: 5,
    marginBottom: 30
  },
  images:{
    width: 200,
    height: 300,
    borderWidth:3,
    borderColor: '#514155'
  },
  imagesR:{
    width: 200,
    height: 150,
    borderWidth:3,
    borderColor: '#514155'
  },
  footer:{
    marginTop:20,
    padding:20
  },
  input:{
    borderWidth: 1,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 20,
    textAlign: 'start',
    margin:5
  },
  submit1:{
    backgroundColor: '#514155',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    marginTop: 10,
    borderRadius: 20,
    width: '50%'
  },
  h5:{
    color: '#c2bbc3',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: 'bold',
  },
}