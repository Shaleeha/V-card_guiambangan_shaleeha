import React, {useState} from 'react';
import { View, Image, ScrollView, Text, SafeAreaView, Linking, TouchableOpacity, TextInput } from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import {Styles} from './styles/styles';
import { FontAwesome5 } from '@expo/vector-icons';


export default function Vcard () { 

  const socialMedia = (url) => {
    Linking.openURL(url).catch((err) => console.error("Failed to open URL:", err));
  };

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);
  const [isTimePickerVisible2, setTimePickerVisibility2] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [selectedTime2, setSelectedTime2] = useState('');

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {    setDatePickerVisibility(false);
  };
  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };
  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };
  const showTimePicker2 = () => {
    setTimePickerVisibility2(true);
  };
  const hideTimePicker2 = () => {
    setTimePickerVisibility2(false);
  };
  const handleDateConfirm = (date) => {
    setSelectedDate(date.toISOString().split('T')[0]);
    hideDatePicker();
  };
  const handleTimeConfirm = (time) => {
    setSelectedTime(time.toLocaleTimeString());
    hideTimePicker();
  };
  const handleTimeConfirm2 = (time) => {
    setSelectedTime2(time.toLocaleTimeString());
    hideTimePicker2();
  };

  const [name, onChangeText1] = React.useState('');
  const [email, onChangeText2] = React.useState('');
  const [message, onChangeText3] = React.useState('');


  return(
    <SafeAreaView style={Styles.container}>
    <ScrollView>

     <View style={Styles.header}>
        <Image
          style={Styles.headerImage}
          source={require('./assets/header.jpg')}
        />
        <View style={Styles.profile}>
          <Image
            style={Styles.profileImage}
            source={require('./assets/picture.jpg')}
          />
          <Text style={Styles.h1}>Shaleeha T. Guiambangan</Text>
          <Text style={Styles.h3}>IT Student</Text>
        </View>
      </View>

      <View style={Styles.socialMedia}>
        <TouchableOpacity 
          onPress={( ) => socialMedia('https://www.facebook.com/princessleah.lacdao')}>
        <FontAwesome5 
          name="facebook"
          size={25}
          color="#514155"
          style={Styles.icon} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => socialMedia('https://www.instagram.com/_moon_x_luna_?igsh=MTc0cG5hYmd6M2hhZg==')}>
          <FontAwesome5
            name="instagram"
            size={25}
            color="#514155"
            style={Styles.icon} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => socialMedia('https://www.tiktok.com/@shaleehag?_t=8mkCkNXlerWk&)_r=1')}>
          <FontAwesome5
            name="tiktok"
            size={25}
            color="#514155"
            style={Styles.icon} />
        </TouchableOpacity>
      </View>


      <View style={Styles.introduction}>
        <Text style={Styles.h3}> I'm currently studying Information Technology at GRC, because I'm fascinated by how technology works and love exploring what I can do with it. Besides my IT studies, I've also learned to make great coffee and tasty bread and pastries. Outside of class, I enjoy taking photos, drawing, and painting. These hobbies let me express myself and have fun while learning new things
        </Text>
      </View>
      <View style={Styles.contacts}>
      <TouchableOpacity onPress={() => Linking.openURL('https://mail.google.com/mail/u/0/?hl=en/&pli=1#inbox')}>
       <View style={Styles.card}>
         <FontAwesome5
            name="envelope"
            size={25}
            color="#514155"
            style={Styles.icon}
            />
         <Text style={Styles.contact}>guiambanganshaleeha@gmail.com</Text>
      </View>
     </TouchableOpacity>
        <View style={Styles.card}>
          <FontAwesome5
            name="phone"
            size={25}
            color="#514155"
            style={Styles.icon} />
          <Text style={Styles.contact}>09656431179</Text>
        </View>
        <View style={Styles.merge}>
          <View style={Styles.cardSub}>
            <FontAwesome5
              name="birthday-cake"
              size={25}
              color="#514155"
              style={Styles.icon} />
            <Text style={Styles.contact}>04-19-2002</Text>
          </View>
          <View style={Styles.cardSub}>
            <FontAwesome5
              name="map"
              size={25}
              color="#514155"
              style={Styles.icon} />
            <Text style={Styles.contact}>Manila City</Text>
          </View>
        </View>
      </View>

      <View style={Styles.appointment}>
        <Text style={Styles.h2}>Make an Appointment</Text>
          <View style={Styles.dateDay}>
            <Text style={Styles.h3}>Date</Text>
            <TouchableOpacity onPress={showDatePicker}>
              <Text style={Styles.datePickerText}>{selectedDate || 'YYYY-MM-DD'}</Text>
            </TouchableOpacity>
            <DateTimePickerModal
              isVisible={isDatePickerVisible}
              mode="date"
              onConfirm={handleDateConfirm}
              onCancel={hideDatePicker}
                />
            </View>
            <View>
              <Text style={Styles.h3}>Hour</Text>
              <View style={Styles.hour}>
                <TouchableOpacity onPress={showTimePicker}>
                  <Text style={Styles.timePickerText}>{selectedTime || 'HH:MM'}</Text>
                </TouchableOpacity>
                <DateTimePickerModal
                  isVisible={isTimePickerVisible}
                  mode="time"
                  onConfirm={handleTimeConfirm}
                  onCancel={hideTimePicker}
                />
                <Text style={Styles.timePickerText}> - </Text>
                <TouchableOpacity onPress={showTimePicker2}>
                  <Text style={Styles.timePickerText}>{selectedTime2 || 'HH:MM'}</Text>
                </TouchableOpacity>
                <DateTimePickerModal
                  isVisible={isTimePickerVisible2}
                  mode="time"
                  onConfirm={handleTimeConfirm2}
                  onCancel={hideTimePicker2}
                />
              </View>
              <View style={Styles.btn}>
                <TouchableOpacity style={Styles.submit}>
                  <Text style={Styles.h4}>Make an Appointment</Text>
                </TouchableOpacity>
              </View>
            </View>
      </View>

      <View>
        <Text style={Styles.h2}> ART GALLERY </Text>
        <View style={Styles.gallery}>
          <Image
            style={Styles.images}
            source={require('./assets/painting2.jpg')}
          />
          <View>
            <Image
              style={Styles.imagesR}
              source={require('./assets/painting.jpg')}
            />
             <Image
              style={Styles.imagesR}
              source={require('./assets/digiArts.jpg')}
            />
          </View>
        </View>
      </View>

      <View style={Styles.footer}>
        <Text style={Styles.h2}>Contact Us!</Text>
          <TextInput
              style={Styles.input}
              onChangeText={onChangeText1}
              value={name}
              placeholder="Name"
            />
          <TextInput
              style={Styles.input}
              onChangeText={onChangeText2}
              value={email}
              placeholder="Email"
            />
          <TextInput
              style={Styles.input}
              editable
              multiline
              numberOfLines={3}
              maxLength={30}
              onChangeText={text => onChangeText3(text)}
              value={message}
              placeholder="Type your message here."
            />
            <View style={Styles.btn}>
              <TouchableOpacity style={Styles.submit1}>
                <Text style={Styles.h5}>Send Message</Text>
              </TouchableOpacity>
            </View>
      </View>
     </ScrollView>
     </SafeAreaView>
  );
}